import{i as s}from"./index-58c6a9a2.js";import{c as n}from"./utils-3f044a58.js";import{c}from"./createLucideIcon-ce280df7.js";import{E as r,f as l,g as u,L as p,u as e,o as i,J as d,j as m}from"./app-ac1f9e43.js";/**
 * @license lucide-vue-next v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=c("ChevronRightIcon",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]),B=r({__name:"MenubarSubTrigger",props:{disabled:{type:Boolean},textValue:{},asChild:{type:Boolean},as:{},inset:{type:Boolean},class:{}},setup(t){const a=t;return(o,h)=>(i(),l(e(s),p(a,{class:[e(n)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",t.inset&&"pl-8",a.class)]}),{default:u(()=>[d(o.$slots,"default"),m(e(f),{class:"ml-auto h-4 w-4"})]),_:3},16,["class"]))}});export{B as default};
