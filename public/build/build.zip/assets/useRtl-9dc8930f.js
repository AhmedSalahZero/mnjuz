import{Q as e,m as o}from"./app-ac1f9e43.js";function i(){const r=e(),t=o(()=>r.props.isRtl),s=o(()=>({"direction-rtl":t.value,"direction-ltr":!t.value}));return{isRtl:t,rtlClass:s}}export{i as u};
