import{_ as o}from"./MenubarMenu.vue_vue_type_script_setup_true_lang-f75ee1d7.js";import"./index-58c6a9a2.js";import"./app-ac1f9e43.js";export{o as default};
