<?php

return [
    // Action name => active (true/false)
    'add_to_group'      => true,
    'remove_from_group' => true,
    'update_contact'    => true,
    'send_email'        => true,
    'delay'             => true,
    'webhook'           => true,
    'ai_response'       => false, // Disabled
    'conditional'       => false,
    // Add more actions as needed
]; 